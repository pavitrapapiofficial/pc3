#How to upload ProductEnquiry for products, categories in Magneto 2.
